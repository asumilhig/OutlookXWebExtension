
function reloadPage() {
    // var datasrc = document.getElementById("datasrc");
    // datasrc.setAttribute("src",'data.js');

    // location.reload();

    reloadPopup();
    
    setTimeout(reloadPage,5000);
}

reloadPage();
