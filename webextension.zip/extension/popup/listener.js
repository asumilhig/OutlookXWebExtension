
// PDFJS.workerSrc = document.getElementById("pdf-js").getAttribute("src");
// var app = new App;

// var input = document.getElementById("input");
// var processor = document.getElementById("processor");
// var output = document.getElementById("output");
// var pdfdata;

// window.addEventListener("message", function(event){      
  // switch (event.data){
  //   case "ready":
  //     var xhr = new XMLHttpRequest;
  //     xhr.open('GET', input.getAttribute("src"), true);
  //     xhr.responseType = "arraybuffer";
      
  //     xhr.onload = function(event) {
  //       window.postMessage(xhr.response, "*");
  //     };

  //     xhr.send();
  //   break;
    
    // default:
      
      // var result = event.data.replace(/\s+/g, " ");
      // output.textContent = result;
      // console.log(event);
  //   break;
  // }
// }, true);


