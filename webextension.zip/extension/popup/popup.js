
// var reloadPopup = function(){
    
// Initialize pdf to text worker
PDFJS.workerSrc = document.getElementById("pdf-js").getAttribute("src");
var app = new App;

var str = '';
var output = document.getElementById("output");
var pdfdata;
var result;

data.forEach(item => {
    var attsrc = "";
    if (item.Attachments.length > 0){
        attsrc = item.Attachments[0];
        
        str += '<tr onclick="searchSubject(this)"><td>' + item.Sender + '</td>' +
            '<td class="subject">' + item.Subject + '</td>' +
            '<td>' + item.ReceivedTime + '</td>' +
            '<td class="attachment">' + attsrc + '</td></tr>';
    }
    
});

document.getElementById("tbodyContent").innerHTML = str;


function sendID(){
    var eid = document.getElementById("entry");
    console.log(eid.value);
}

// ------------ message passing

function notifyBackgroundPage(e) {
    chrome.runtime.sendMessage({message: e}, (response) => {
        document.getElementById("error-content").innerHTML = "Your message is: " + response.message + "<br> Response: " + response.response;
    });
}


document.addEventListener('DOMContentLoaded', function() {

    console.log('DOMContentLoaded');

    window.onclick = function(event){
        var target = event.target;
        if (target.matches(".attachment")){

            notifyBackgroundPage(target.innerText);

            var pdfPath = "img/" + target.innerText;

            document.getElementById("input").src = pdfPath;

            result = "";

            var xhr = new XMLHttpRequest;
            xhr.open("GET", pdfPath, true);
            xhr.responseType = "arraybuffer";

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4) {
                    console.log('sending xhr response to window');
                    
                    window.postMessage(xhr.response, "*");
                    // app.setInput(xhr.response);
                }
            }
                        
            xhr.send();
            
        }else{
            document.getElementById("error-content").innerHTML = "Error handler."
        }
    }

});

