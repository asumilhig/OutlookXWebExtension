

chrome.runtime.onMessage.addListener(

    function (request, sender, sendResponse){
        
        let begin_search = new MouseEvent('click', {
            view: window,
            bubbles: true,
            cancelable: true
        });

        let search_box = document.querySelector('.gLFyf');
        let search_button = document.querySelector('.gNO89b');

        if (search_button == null){
            search_button = document.querySelector('.Tg7LZd');
        }

        search_box.value = request.data;
        search_button.dispatchEvent(begin_search);

        console.log(request);
        
        sendResponse({message: "Hi background script, here's my message from content script " + request.data});
    }
);

