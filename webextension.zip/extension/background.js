

function handleRequest(request, sender, sendResponse) {
  console.log(request);

  var pdfPath = "popup/img/" + request.message;

  if(request.message){
    var data = {message: pdfPath, response: "Hi popup from bg!"};
  }else{
    var data = {message: pdfPath, response: "Unknown greeting popup!"};
  }
  
  sendResponse(data);

  sendCopyToContentScript(data);
}

chrome.runtime.onMessage.addListener(handleRequest);


function sendCopyToContentScript(data){
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {data: data.message}, function(resp) {
        
        console.log(resp.message);
      });
    }
  );
}